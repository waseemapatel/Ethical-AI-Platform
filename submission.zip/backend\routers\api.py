import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Dict, Any

from ..database import get_db
from ..models import Applicant, DecisionLog
from ..schemas import ApplicantCreate, ApplicantResponse, TieBreakResolve
from ..services.ai_service import ai_service
from ..services.scoring_service import scoring_service

router = APIRouter()

@router.post("/process-applicant", response_model=ApplicantResponse)
def process_applicant(applicant: ApplicantCreate, db: Session = Depends(get_db)):
    data_dict = applicant.dict()
    
    # 1. AI Redaction & Proxy Bias Check
    redacted_data, proxy_bias_flagged = ai_service.process_applicant_data(data_dict)
    
    # 2. Merit Scoring
    skill_score = (0.5 * applicant.skill)
    exp_score = (0.3 * applicant.experience)
    qual_score = (0.2 * applicant.qualification)
    final_score = scoring_service.calculate_score(applicant.skill, applicant.experience, applicant.qualification)
    
    # 3. AI Justification
    justification = ai_service.generate_justification(redacted_data, final_score, proxy_bias_flagged)
    
    # 4. Tie-Break Detection
    # Look for existing processed applicants with almost identical scores
    status = "Processed"
    existing_applicants = db.query(Applicant).filter(Applicant.status == "Processed").all()
    for existing in existing_applicants:
        if scoring_service.check_tie_break(final_score, existing.final_score):
            status = "Tie-Break"
            existing.status = "Tie-Break" # Both go to human review
            db.commit()
            break
            
    new_app = Applicant(
        original_data=json.dumps(data_dict),
        redacted_data=json.dumps(redacted_data),
        skill_score=skill_score,
        experience_score=exp_score,
        qualification_score=qual_score,
        final_score=final_score,
        status=status,
        justification=justification,
        proxy_bias_flagged=proxy_bias_flagged
    )
    
    db.add(new_app)
    db.commit()
    db.refresh(new_app)
    
    # Convert string back to dict for response
    response_data = new_app.__dict__.copy()
    response_data["redacted_data"] = json.loads(new_app.redacted_data)
    
    return response_data

@router.get("/tie-breaks")
def get_tie_breaks(db: Session = Depends(get_db)):
    applicants = db.query(Applicant).filter(Applicant.status == "Tie-Break").all()
    results = []
    for app in applicants:
        data = app.__dict__.copy()
        data["redacted_data"] = json.loads(app.redacted_data)
        results.append(data)
    return results

@router.post("/resolve-tie")
def resolve_tie_break(resolution: TieBreakResolve, db: Session = Depends(get_db)):
    app1 = db.query(Applicant).filter(Applicant.id == resolution.applicant_1_id).first()
    app2 = db.query(Applicant).filter(Applicant.id == resolution.applicant_2_id).first()
    
    if not app1 or not app2:
        raise HTTPException(status_code=404, detail="Applicants not found")
        
    app1_orig = json.loads(app1.original_data)
    app2_orig = json.loads(app2.original_data)
    
    # Log the decision
    log = DecisionLog(
        manager_id=resolution.manager_id,
        applicant_1_id=app1.id,
        applicant_2_id=app2.id,
        selected_applicant_id=resolution.selected_applicant_id,
        demographics_selected=json.dumps({"gender": app1_orig.get("gender") if resolution.selected_applicant_id == app1.id else app2_orig.get("gender"), "race": app1_orig.get("race") if resolution.selected_applicant_id == app1.id else app2_orig.get("race")}),
        demographics_rejected=json.dumps({"gender": app2_orig.get("gender") if resolution.selected_applicant_id == app1.id else app1_orig.get("gender"), "race": app2_orig.get("race") if resolution.selected_applicant_id == app1.id else app1_orig.get("race")})
    )
    db.add(log)
    
    # Update statuses
    if resolution.selected_applicant_id == app1.id:
        app1.status = "Selected"
        app2.status = "Rejected"
    else:
        app2.status = "Selected"
        app1.status = "Rejected"
        
    db.commit()
    return {"message": "Tie resolved successfully"}

@router.get("/fairness-audit")
def fairness_audit(db: Session = Depends(get_db)):
    logs = db.query(DecisionLog).all()
    
    total_decisions = len(logs)
    bias_alert = False
    stats = {"male_favored": 0, "female_favored": 0}
    
    for log in logs:
        selected_demo = json.loads(log.demographics_selected)
        if selected_demo.get("gender") == "Male":
            stats["male_favored"] += 1
        elif selected_demo.get("gender") == "Female":
            stats["female_favored"] += 1
            
    # Simple check: if >90% favor one demographic
    if total_decisions >= 3:
        if stats["male_favored"] / total_decisions > 0.9 or stats["female_favored"] / total_decisions > 0.9:
            bias_alert = True
            
    # Calculate simulated Total Loss = Prediction Loss + λ(Bias)
    # Using Proxy Bias frequency for Bias
    total_applicants = db.query(Applicant).count()
    proxy_flags = db.query(Applicant).filter(Applicant.proxy_bias_flagged == True).count()
    bias_lambda = 0.5
    bias_score = (proxy_flags / total_applicants) if total_applicants > 0 else 0
    prediction_loss = 0.1 # Base mock loss
    total_loss = prediction_loss + (bias_lambda * bias_score)
    
    return {
        "total_tie_breaks_resolved": total_decisions,
        "manager_bias_stats": stats,
        "bias_alert": bias_alert,
        "system_loss_metrics": {
            "prediction_loss": prediction_loss,
            "bias_penalty": bias_lambda * bias_score,
            "total_loss": total_loss
        }
    }
