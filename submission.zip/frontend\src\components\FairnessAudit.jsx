import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { ShieldAlert, TrendingDown, AlertTriangle, Scale } from 'lucide-react';

const API_URL = 'http://localhost:8000/api';

export default function FairnessAudit() {
  const [auditData, setAuditData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAudit = async () => {
      try {
        const response = await axios.get(`${API_URL}/fairness-audit`);
        setAuditData(response.data);
      } catch (error) {
        console.error(error);
      }
      setLoading(false);
    };
    fetchAudit();
  }, []);

  if (loading) return <div className="p-8 text-center text-slate-400">Loading Audit Data...</div>;

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center gap-3 mb-2">
        <ShieldAlert className="w-8 h-8 text-error" />
        <h2 className="text-3xl font-bold tracking-tight">Fairness Audit</h2>
      </div>
      <p className="text-slate-400 mb-8">Monitoring AI integrity and detecting human bias reappearance.</p>

      {auditData?.bias_alert && (
        <div className="bg-error/10 border border-error p-6 rounded-xl flex items-start gap-4 shadow-lg shadow-error/10 animate-pulse">
          <AlertTriangle className="w-8 h-8 text-error shrink-0 mt-1" />
          <div>
            <h3 className="text-xl font-bold text-error mb-2">CRITICAL: Possible Human Bias Detected</h3>
            <p className="text-error/90 text-sm leading-relaxed">
              The system log indicates that managers are favoring a specific demographic in over 90% of manual tie-break decisions. 
              While the AI successfully removed bias during initial screening, human intervention is reintroducing it. Immediate review of manager decision logs is required.
            </p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="card space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-700 pb-4">
            <UsersIcon className="w-6 h-6 text-primary" />
            <h3 className="text-xl font-bold text-slate-200">Manager Tie-Break Patterns</h3>
          </div>
          
          <div className="space-y-6 pt-2">
            <div>
              <div className="flex justify-between text-sm mb-2 text-slate-300">
                <span>Male Favored</span>
                <span className="font-bold">{auditData?.manager_bias_stats.male_favored} cases</span>
              </div>
              <div className="h-4 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-500 transition-all duration-1000" 
                  style={{width: `${(auditData?.manager_bias_stats.male_favored / Math.max(auditData?.total_tie_breaks_resolved, 1)) * 100}%`}}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-sm mb-2 text-slate-300">
                <span>Female Favored</span>
                <span className="font-bold">{auditData?.manager_bias_stats.female_favored} cases</span>
              </div>
              <div className="h-4 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-pink-500 transition-all duration-1000" 
                  style={{width: `${(auditData?.manager_bias_stats.female_favored / Math.max(auditData?.total_tie_breaks_resolved, 1)) * 100}%`}}
                ></div>
              </div>
            </div>
            
            <div className="pt-4 flex justify-between text-xs text-slate-500 border-t border-slate-700">
              <span>Total Manual Decisions: {auditData?.total_tie_breaks_resolved}</span>
              <span>Threshold for alert: &gt;90% variance</span>
            </div>
          </div>
        </div>

        <div className="card space-y-6">
          <div className="flex items-center gap-3 border-b border-slate-700 pb-4">
            <TrendingDown className="w-6 h-6 text-secondary" />
            <h3 className="text-xl font-bold text-slate-200">Fairness Penalty Metric</h3>
          </div>
          
          <div className="space-y-6 pt-2">
            <p className="text-sm text-slate-400">Total Loss = Prediction Loss + λ(Bias)</p>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-surface border border-slate-700 rounded-lg p-4 text-center">
                <span className="block text-xs text-slate-500 mb-1 uppercase tracking-wider">Prediction Loss</span>
                <span className="text-2xl font-mono text-slate-300">{auditData?.system_loss_metrics.prediction_loss.toFixed(3)}</span>
              </div>
              <div className="bg-surface border border-slate-700 rounded-lg p-4 text-center">
                <span className="block text-xs text-slate-500 mb-1 uppercase tracking-wider">Bias Penalty (λ)</span>
                <span className="text-2xl font-mono text-accent">{auditData?.system_loss_metrics.bias_penalty.toFixed(3)}</span>
              </div>
            </div>
            
            <div className="bg-surface border border-slate-700 rounded-lg p-6 text-center shadow-inner">
              <span className="block text-sm text-slate-400 mb-2 uppercase tracking-widest font-semibold">Total System Loss</span>
              <span className="text-5xl font-mono font-bold text-white bg-clip-text text-transparent bg-gradient-to-r from-secondary to-primary">
                {auditData?.system_loss_metrics.total_loss.toFixed(3)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Temporary icon to replace missing import above if needed
function UsersIcon(props) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}
