class ScoringService:
    def calculate_score(self, skill: float, experience: float, qualification: float) -> float:
        # Score = 0.5*Skill + 0.3*Experience + 0.2*Qualification
        score = (0.5 * skill) + (0.3 * experience) + (0.2 * qualification)
        return score
        
    def check_tie_break(self, score1: float, score2: float) -> bool:
        # If |Score1 - Score2| < 0.01, halt AI, trigger Human Decision Stage
        return abs(score1 - score2) < 0.01

scoring_service = ScoringService()
