import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Users, CheckCircle, AlertCircle } from 'lucide-react';

const API_URL = 'http://localhost:8000/api';

export default function HumanDecisionStage() {
  const [tieBreaks, setTieBreaks] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchTieBreaks = async () => {
    try {
      const response = await axios.get(`${API_URL}/tie-breaks`);
      setTieBreaks(response.data);
    } catch (error) {
      console.error(error);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchTieBreaks();
  }, []);

  const handleResolve = async (app1_id, app2_id, selected_id) => {
    try {
      await axios.post(`${API_URL}/resolve-tie`, {
        manager_id: "manager_123",
        applicant_1_id: app1_id,
        applicant_2_id: app2_id,
        selected_applicant_id: selected_id
      });
      fetchTieBreaks(); // Refresh list
    } catch (error) {
      console.error(error);
      alert("Error resolving tie break");
    }
  };

  if (loading) return <div className="p-8 text-center text-slate-400">Loading...</div>;

  // Group into pairs for prototype demo
  const pairs = [];
  for (let i = 0; i < tieBreaks.length; i += 2) {
    if (tieBreaks[i+1]) {
      pairs.push([tieBreaks[i], tieBreaks[i+1]]);
    }
  }

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center gap-3 mb-2">
        <Users className="w-8 h-8 text-amber-500" />
        <h2 className="text-3xl font-bold tracking-tight">Human Decision Stage</h2>
      </div>
      <p className="text-slate-400 mb-8">AI halted due to score difference &lt; 0.01. Human manager must decide.</p>

      {pairs.length === 0 ? (
        <div className="card flex flex-col items-center justify-center p-12 text-center border-slate-700/50">
          <CheckCircle className="w-12 h-12 text-secondary mb-4 opacity-50" />
          <h3 className="text-xl font-medium text-slate-300">No Pending Tie-Breaks</h3>
          <p className="text-slate-500 mt-2">All applications have clear score differentials.</p>
        </div>
      ) : (
        <div className="space-y-8">
          {pairs.map((pair, idx) => (
            <div key={idx} className="card border-amber-500/20 bg-amber-500/5">
              <div className="flex items-center gap-2 text-amber-500 mb-6 border-b border-amber-500/20 pb-3">
                <AlertCircle className="w-5 h-5" />
                <h3 className="font-semibold">Tie-Break Pair #{idx + 1}</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {pair.map((app) => (
                  <div key={app.id} className="bg-surface border border-slate-700 rounded-lg p-5 flex flex-col h-full">
                    <div className="flex justify-between items-center mb-4">
                      <h4 className="text-lg font-bold text-slate-200">Applicant ID: {app.id}</h4>
                      <span className="bg-primary/20 text-primary text-xs font-bold px-2 py-1 rounded">Score: {app.final_score.toFixed(3)}</span>
                    </div>
                    
                    <div className="space-y-3 flex-1 text-sm text-slate-300">
                      <div><span className="text-slate-500">Skill:</span> {app.skill_score / 0.5}</div>
                      <div><span className="text-slate-500">Experience:</span> {app.experience_score / 0.3}</div>
                      <div><span className="text-slate-500">Qualification:</span> {app.qualification_score / 0.2}</div>
                      
                      <div className="mt-4 pt-4 border-t border-slate-700">
                        <span className="text-slate-500 block mb-1">AI Notes:</span>
                        <p className="text-xs">{app.justification}</p>
                      </div>
                    </div>
                    
                    <button 
                      onClick={() => handleResolve(pair[0].id, pair[1].id, app.id)}
                      className="mt-6 w-full btn-primary bg-amber-600 hover:bg-amber-700 shadow-amber-600/20"
                    >
                      Select Applicant
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
