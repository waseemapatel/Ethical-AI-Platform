from sqlalchemy import Boolean, Column, Float, Integer, String, Text, DateTime
from sqlalchemy.sql import func
from .database import Base

class Applicant(Base):
    __tablename__ = "applicants"

    id = Column(Integer, primary_key=True, index=True)
    original_data = Column(Text) # JSON string of original data
    redacted_data = Column(Text) # JSON string of redacted data
    
    skill_score = Column(Float)
    experience_score = Column(Float)
    qualification_score = Column(Float)
    final_score = Column(Float)
    
    status = Column(String, default="Processed") # "Processed", "Tie-Break", "Selected", "Rejected"
    justification = Column(Text)
    proxy_bias_flagged = Column(Boolean, default=False)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class DecisionLog(Base):
    __tablename__ = "decision_logs"

    id = Column(Integer, primary_key=True, index=True)
    manager_id = Column(String)
    applicant_1_id = Column(Integer)
    applicant_2_id = Column(Integer)
    selected_applicant_id = Column(Integer)
    
    # Store demographics internally to monitor bias (not shown to manager)
    demographics_selected = Column(Text)
    demographics_rejected = Column(Text)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
