import React from 'react';
import { Activity, ShieldCheck, AlertOctagon, Users } from 'lucide-react';

export default function Dashboard() {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div>
        <h2 className="text-3xl font-bold tracking-tight mb-2">Platform Overview</h2>
        <p className="text-slate-400">Monitor AI decisioning and system health.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="card border-primary/20 bg-primary/5">
          <div className="flex items-center justify-between pb-4">
            <h3 className="font-semibold text-slate-300">Total Processed</h3>
            <Activity className="w-5 h-5 text-primary" />
          </div>
          <p className="text-3xl font-bold">124</p>
          <p className="text-sm text-primary mt-2">Active pipeline</p>
        </div>

        <div className="card border-secondary/20 bg-secondary/5">
          <div className="flex items-center justify-between pb-4">
            <h3 className="font-semibold text-slate-300">AI Selections</h3>
            <ShieldCheck className="w-5 h-5 text-secondary" />
          </div>
          <p className="text-3xl font-bold">89</p>
          <p className="text-sm text-secondary mt-2">Zero demographic bias</p>
        </div>

        <div className="card border-amber-500/20 bg-amber-500/5">
          <div className="flex items-center justify-between pb-4">
            <h3 className="font-semibold text-slate-300">Tie-Breaks</h3>
            <Users className="w-5 h-5 text-amber-500" />
          </div>
          <p className="text-3xl font-bold">35</p>
          <p className="text-sm text-amber-500 mt-2">Pending human review</p>
        </div>

        <div className="card border-accent/20 bg-accent/5">
          <div className="flex items-center justify-between pb-4">
            <h3 className="font-semibold text-slate-300">Proxy Bias Flagged</h3>
            <AlertOctagon className="w-5 h-5 text-accent" />
          </div>
          <p className="text-3xl font-bold">12</p>
          <p className="text-sm text-accent mt-2">Hidden indicators ignored</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="card space-y-4">
          <h3 className="text-xl font-bold">How the AI Works</h3>
          <ul className="space-y-4">
            <li className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center shrink-0 font-bold text-primary">1</div>
              <div>
                <h4 className="font-semibold">Sensitive Data Filtering</h4>
                <p className="text-sm text-slate-400">Gemini 1.5 Pro redacts Name, Gender, Race, etc.</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center shrink-0 font-bold text-primary">2</div>
              <div>
                <h4 className="font-semibold">Proxy Bias Detection</h4>
                <p className="text-sm text-slate-400">Flags hidden indicators like specific addresses.</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center shrink-0 font-bold text-primary">3</div>
              <div>
                <h4 className="font-semibold">Merit-Based Scoring</h4>
                <p className="text-sm text-slate-400">0.5*Skill + 0.3*Experience + 0.2*Qualification</p>
              </div>
            </li>
            <li className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center shrink-0 font-bold text-primary">4</div>
              <div>
                <h4 className="font-semibold">Tie-Break Detection</h4>
                <p className="text-sm text-slate-400">Halts AI if |Score1 - Score2| &lt; 0.01.</p>
              </div>
            </li>
          </ul>
        </div>
        
        <div className="card relative overflow-hidden flex flex-col justify-center items-center text-center p-8 bg-gradient-to-br from-surface to-slate-800">
           <div className="absolute inset-0 bg-grid-slate-800/[0.04] bg-[bottom_1px_center] dark:bg-grid-slate-400/[0.05] dark:bg-bottom dark:border-b dark:border-slate-100/5"></div>
           <ShieldCheck className="w-16 h-16 text-primary mb-4 relative z-10" />
           <h3 className="text-2xl font-bold mb-2 relative z-10">AI Model: Gemini 1.5 Pro</h3>
           <p className="text-slate-400 relative z-10">Powering PII redaction and explainability via Vertex AI integration.</p>
        </div>
      </div>
    </div>
  );
}
