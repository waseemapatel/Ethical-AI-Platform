from pydantic import BaseModel
from typing import Dict, Any, Optional

class ApplicantCreate(BaseModel):
    name: str
    gender: Optional[str] = None
    race: Optional[str] = None
    skill: float # 0-100
    experience: float # 0-100
    qualification: float # 0-100
    address: Optional[str] = None
    hobbies: Optional[str] = None

class ApplicantResponse(BaseModel):
    id: int
    redacted_data: Dict[str, Any]
    skill_score: float
    experience_score: float
    qualification_score: float
    final_score: float
    status: str
    justification: str
    proxy_bias_flagged: bool

    class Config:
        orm_mode = True

class TieBreakResolve(BaseModel):
    manager_id: str
    applicant_1_id: int
    applicant_2_id: int
    selected_applicant_id: int
