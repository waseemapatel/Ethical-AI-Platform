import React, { useState } from 'react';
import { Send, CheckCircle, AlertTriangle } from 'lucide-react';
import axios from 'axios';

const API_URL = 'http://localhost:8000/api';

export default function ApplicationForm() {
  const [formData, setFormData] = useState({
    name: '', gender: '', race: '', skill: '', experience: '', qualification: '', address: '', hobbies: ''
  });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await axios.post(`${API_URL}/process-applicant`, {
        ...formData,
        skill: parseFloat(formData.skill),
        experience: parseFloat(formData.experience),
        qualification: parseFloat(formData.qualification)
      });
      setResult(response.data);
      // Reset form if desired
    } catch (error) {
      console.error(error);
      alert("Error processing application");
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div>
        <h2 className="text-3xl font-bold tracking-tight mb-2">Submit Application</h2>
        <p className="text-slate-400">Enter applicant details. PII will be automatically redacted by the AI before scoring.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <form onSubmit={handleSubmit} className="card space-y-6">
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-slate-300 border-b border-slate-700 pb-2">Personal Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <input type="text" placeholder="Full Name" className="input-field" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} required />
              <select className="input-field" value={formData.gender} onChange={e => setFormData({...formData, gender: e.target.value})} required>
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Non-binary">Non-binary</option>
              </select>
              <input type="text" placeholder="Race/Ethnicity" className="input-field col-span-2" value={formData.race} onChange={e => setFormData({...formData, race: e.target.value})} required />
            </div>

            <h3 className="text-lg font-medium text-slate-300 border-b border-slate-700 pb-2 pt-4">Metrics (0-100)</h3>
            <div className="grid grid-cols-3 gap-4">
              <input type="number" placeholder="Skill" className="input-field" value={formData.skill} onChange={e => setFormData({...formData, skill: e.target.value})} required min="0" max="100"/>
              <input type="number" placeholder="Experience" className="input-field" value={formData.experience} onChange={e => setFormData({...formData, experience: e.target.value})} required min="0" max="100"/>
              <input type="number" placeholder="Qualification" className="input-field" value={formData.qualification} onChange={e => setFormData({...formData, qualification: e.target.value})} required min="0" max="100"/>
            </div>

            <h3 className="text-lg font-medium text-slate-300 border-b border-slate-700 pb-2 pt-4">Additional Data</h3>
            <div className="grid grid-cols-1 gap-4">
              <input type="text" placeholder="Address / Zip Code" className="input-field" value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} />
              <input type="text" placeholder="Hobbies" className="input-field" value={formData.hobbies} onChange={e => setFormData({...formData, hobbies: e.target.value})} />
            </div>
          </div>
          
          <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
            {loading ? 'Processing via AI...' : <><Send className="w-4 h-4" /> Process Application</>}
          </button>
        </form>

        {result && (
          <div className="card border-primary/30 bg-primary/5 space-y-6 animate-in zoom-in-95 duration-300">
            <div className="flex items-center gap-3 text-primary">
              <CheckCircle className="w-6 h-6" />
              <h3 className="text-xl font-bold">AI Processing Complete</h3>
            </div>
            
            <div className="space-y-4">
              <div className="bg-surface p-4 rounded-lg border border-slate-700">
                <span className="text-sm text-slate-400 uppercase tracking-wider font-semibold block mb-2">Redacted Data (What the AI saw)</span>
                <pre className="text-xs text-slate-300 overflow-x-auto">
                  {JSON.stringify(result.redacted_data, null, 2)}
                </pre>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-surface p-4 rounded-lg border border-slate-700 text-center">
                  <span className="text-sm text-slate-400 block mb-1">Final Score</span>
                  <span className="text-3xl font-bold text-white">{result.final_score.toFixed(2)}</span>
                </div>
                <div className="bg-surface p-4 rounded-lg border border-slate-700 text-center flex flex-col justify-center items-center">
                  <span className="text-sm text-slate-400 block mb-1">Status</span>
                  <span className={`text-lg font-bold px-3 py-1 rounded-full ${result.status === 'Tie-Break' ? 'bg-amber-500/20 text-amber-400' : 'bg-primary/20 text-primary'}`}>
                    {result.status}
                  </span>
                </div>
              </div>

              {result.proxy_bias_flagged && (
                <div className="bg-amber-500/10 border border-amber-500/50 p-4 rounded-lg flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-amber-500">Proxy Bias Flagged</h4>
                    <p className="text-sm text-amber-500/80 mt-1">Hidden demographic indicators (e.g., zip code or specific hobbies) were detected and actively ignored by the AI.</p>
                  </div>
                </div>
              )}

              <div className="bg-surface p-4 rounded-lg border border-slate-700">
                <span className="text-sm text-slate-400 uppercase tracking-wider font-semibold block mb-2">Explainable AI Justification</span>
                <p className="text-sm text-slate-300 leading-relaxed">
                  {result.justification}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
