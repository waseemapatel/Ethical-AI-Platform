import json

class MockAIService:
    def process_applicant_data(self, data: dict):
        # 1. Sensitive Data Filtering
        redacted = data.copy()
        for key in ["name", "gender", "race", "religion", "caste", "language", "region", "skin_color"]:
            if key in redacted:
                redacted[key] = "[REDACTED]"
        
        # 6. Proxy Bias Detection
        proxy_bias_flagged = False
        hobbies = data.get("hobbies", "").lower()
        address = data.get("address", "").lower()
        
        # Simple mock logic for proxy indicators
        if "polo" in hobbies or "golf" in hobbies:
            proxy_bias_flagged = True
        if "zip" in address or "specific_neighborhood" in address:
            proxy_bias_flagged = True
            
        return redacted, proxy_bias_flagged
        
    def generate_justification(self, redacted_data: dict, score: float, proxy_flagged: bool) -> str:
        justification = f"Selected primarily on merit with a score of {score:.2f} based on Skill, Experience, and Qualification."
        if proxy_flagged:
            justification += " Note: Proxy indicators were detected and ignored in the AI process."
        justification += " All demographic identity factors were strictly excluded from the decision logic."
        return justification

ai_service = MockAIService()
