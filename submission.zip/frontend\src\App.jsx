import React, { useState } from 'react';
import Dashboard from './components/Dashboard';
import ApplicationForm from './components/ApplicationForm';
import HumanDecisionStage from './components/HumanDecisionStage';
import FairnessAudit from './components/FairnessAudit';
import { Activity, Users, ShieldAlert, FileText, Scale } from 'lucide-react';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderTab = () => {
    switch(activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'apply': return <ApplicationForm />;
      case 'tie-breaks': return <HumanDecisionStage />;
      case 'audit': return <FairnessAudit />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar */}
      <aside className="w-64 bg-surface border-r border-slate-700/50 flex flex-col">
        <div className="p-6 border-b border-slate-700/50 flex items-center gap-3">
          <Scale className="text-primary w-8 h-8" />
          <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-accent">EthicalAI</h1>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <button 
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'dashboard' ? 'bg-primary/10 text-primary font-medium' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
          >
            <Activity className="w-5 h-5" /> Overview
          </button>
          <button 
            onClick={() => setActiveTab('apply')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'apply' ? 'bg-primary/10 text-primary font-medium' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
          >
            <FileText className="w-5 h-5" /> New Application
          </button>
          <button 
            onClick={() => setActiveTab('tie-breaks')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'tie-breaks' ? 'bg-primary/10 text-primary font-medium' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
          >
            <Users className="w-5 h-5" /> Human Review
          </button>
          <button 
            onClick={() => setActiveTab('audit')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === 'audit' ? 'bg-primary/10 text-primary font-medium' : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'}`}
          >
            <ShieldAlert className="w-5 h-5" /> Fairness Audit
          </button>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto p-8 relative">
        <div className="max-w-6xl mx-auto">
          {renderTab()}
        </div>
      </main>
    </div>
  );
}

export default App;
